const TRACKED_HOSTS = {
  'www.netflix.com': 'Netflix',
  'open.spotify.com': 'Spotify',
  'www.youtube.com': 'YouTube',
  'music.youtube.com': 'YouTube Music',
  'www.primevideo.com': 'Prime Video',
};

const FLUSH_ALARM = 'usage-flush';

let activeServiceName = null;
let activeStartTs = null;

function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function hostnameFromUrl(url) {
  try {
    return new URL(url).hostname;
  } catch (_) {
    return null;
  }
}

function serviceFromUrl(url) {
  const host = hostnameFromUrl(url);
  if (!host) return null;
  return TRACKED_HOSTS[host] || null;
}

async function withStorage() {
  return chrome.storage.local.get(['usageByDate', 'backendUrl', 'userId']);
}

async function persistUsageMinutes(serviceName, minutes) {
  if (!serviceName || minutes <= 0) return;

  const data = await withStorage();
  const usageByDate = data.usageByDate || {};
  const date = todayKey();
  usageByDate[date] = usageByDate[date] || {};
  usageByDate[date][serviceName] = (usageByDate[date][serviceName] || 0) + minutes;

  await chrome.storage.local.set({ usageByDate });
}

function elapsedMinutes(startTs) {
  if (!startTs) return 0;
  const diffMs = Date.now() - startTs;
  return Math.floor(diffMs / 60000);
}

async function stopActiveTimer() {
  if (!activeServiceName || !activeStartTs) {
    activeServiceName = null;
    activeStartTs = null;
    return;
  }

  const minutes = elapsedMinutes(activeStartTs);
  await persistUsageMinutes(activeServiceName, minutes);

  activeServiceName = null;
  activeStartTs = null;
}

async function startTimerForService(serviceName) {
  if (!serviceName) {
    await stopActiveTimer();
    return;
  }

  if (activeServiceName === serviceName) {
    return;
  }

  await stopActiveTimer();
  activeServiceName = serviceName;
  activeStartTs = Date.now();
}

async function evaluateActiveTab() {
  const [activeTab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
  const service = activeTab?.url ? serviceFromUrl(activeTab.url) : null;
  await startTimerForService(service);
}

async function flushToBackend() {
  await stopActiveTimer();

  const data = await withStorage();
  const usageByDate = data.usageByDate || {};
  const backendUrl = data.backendUrl || 'http://localhost:8082';
  const userId = Number(data.userId || 1);

  for (const [date, serviceMinutes] of Object.entries(usageByDate)) {
    for (const [serviceName, minutesUsed] of Object.entries(serviceMinutes)) {
      if (!minutesUsed || minutesUsed <= 0) continue;

      try {
        const response = await fetch(`${backendUrl}/api/usage`, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ userId, serviceName, minutesUsed, date }),
        });

        if (response.ok) {
          usageByDate[date][serviceName] = 0;
        }
      } catch (_) {
        // Keep buffered data in storage when backend is unreachable.
      }
    }
  }

  await chrome.storage.local.set({ usageByDate });
}

chrome.alarms.create(FLUSH_ALARM, { periodInMinutes: 5 });

chrome.tabs.onActivated.addListener(() => {
  evaluateActiveTab();
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status !== 'complete') return;
  if (!tab.active) return;
  evaluateActiveTab();
});

chrome.windows.onFocusChanged.addListener(async (windowId) => {
  if (windowId === chrome.windows.WINDOW_ID_NONE) {
    await stopActiveTimer();
    return;
  }
  evaluateActiveTab();
});

chrome.idle.onStateChanged.addListener(async (state) => {
  if (state === 'idle' || state === 'locked') {
    await stopActiveTimer();
  } else {
    evaluateActiveTab();
  }
});

chrome.alarms.onAlarm.addListener(async (alarm) => {
  if (alarm.name === FLUSH_ALARM) {
    await flushToBackend();
    await evaluateActiveTab();
  }
});

chrome.runtime.onStartup.addListener(async () => {
  await evaluateActiveTab();
});

chrome.runtime.onInstalled.addListener(async () => {
  const data = await withStorage();
  await chrome.storage.local.set({
    userId: data.userId || 1,
    backendUrl: data.backendUrl || 'http://localhost:8082',
    usageByDate: data.usageByDate || {},
  });
  await evaluateActiveTab();
});
