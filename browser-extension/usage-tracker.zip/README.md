# Subscription Usage Tracker Extension

A Chrome extension that tracks browser usage time on supported subscription websites and pushes usage data to your backend.

## Tracked Sites (default)

- Netflix
- Spotify
- YouTube / YouTube Music
- Prime Video

You can add more websites by updating `TRACKED_HOSTS` in `background.js`.

## Data Sent to Backend

`POST /api/usage`

```json
{
  "userId": 1,
  "serviceName": "Netflix",
  "minutesUsed": 12,
  "date": "2026-03-18"
}
```

## How To Load

1. Open Chrome and go to `chrome://extensions`.
2. Enable `Developer mode`.
3. Click `Load unpacked` and select this folder.
4. Open extension popup and set:
   - Backend URL (default: `http://localhost:8082`)
   - User ID

## Notes

- The extension flushes usage every 5 minutes.
- If backend is offline, usage remains buffered in local storage and is retried later.
- Only browser tab activity is tracked, not mobile apps or smart TV usage.
