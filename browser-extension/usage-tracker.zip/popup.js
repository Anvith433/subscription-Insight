function todayKey() {
  return new Date().toISOString().slice(0, 10);
}

function renderUsage(usageByDate) {
  const list = document.getElementById('usageList');
  const date = todayKey();
  const todayUsage = usageByDate?.[date] || {};
  const entries = Object.entries(todayUsage).sort((a, b) => b[1] - a[1]);

  if (entries.length === 0) {
    list.innerHTML = '<li><span>No usage captured yet</span><span>0 min</span></li>';
    return;
  }

  list.innerHTML = entries
    .map(([serviceName, minutes]) => `<li><span>${serviceName}</span><span>${minutes} min</span></li>`)
    .join('');
}

async function loadData() {
  const data = await chrome.storage.local.get(['backendUrl', 'userId', 'usageByDate']);
  document.getElementById('backendUrl').value = data.backendUrl || 'http://localhost:8082';
  document.getElementById('userId').value = data.userId || 1;
  renderUsage(data.usageByDate || {});
}

async function saveData() {
  const backendUrl = document.getElementById('backendUrl').value.trim() || 'http://localhost:8082';
  const userId = Number(document.getElementById('userId').value || 1);

  await chrome.storage.local.set({ backendUrl, userId });

  const status = document.getElementById('status');
  status.textContent = 'Saved';
  setTimeout(() => {
    status.textContent = '';
  }, 1500);
}

document.getElementById('saveBtn').addEventListener('click', saveData);
loadData();
